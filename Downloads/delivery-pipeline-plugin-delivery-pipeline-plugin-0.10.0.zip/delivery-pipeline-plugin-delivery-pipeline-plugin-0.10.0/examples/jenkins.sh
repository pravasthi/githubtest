#!/bin/bash
jenkins-jobs --conf jenkins.ini update $1